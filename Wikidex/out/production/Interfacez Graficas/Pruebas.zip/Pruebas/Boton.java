package Pruebas;

import javax.swing.*;
import java.awt.*;

class Boton extends JButton {

    Boton(Pokemon datosPokemon){

        if (datosPokemon.getNroPokedex() != 0) {
            this.setText("#" + datosPokemon.getNroPokedex() + "    " + datosPokemon.getName());
        }else {
            this.setText(datosPokemon.getName());
        }
        Image newimag = datosPokemon.getPokemon().getImage().getScaledInstance(150, 75, Image.SCALE_SMOOTH);
        this.setIcon(new ImageIcon(newimag));
        setHorizontalAlignment(CENTER);
        setHorizontalTextPosition(LEFT);
        setIconTextGap(10);

        this.setBackground(Color.orange);
        //this.setOpaque(false);
        //this.setContentAreaFilled(false);
        //this.setBorderPainted(false);

    }

    /*Boton(String equipo, ImageIcon pokeball){

        this.setText(equipo);
        setHorizontalTextPosition(LEFT);
        Image newimag = pokeball.getImage().getScaledInstance(150, 75, Image.SCALE_SMOOTH);
        this.setIcon(new ImageIcon(newimag));
        setHorizontalAlignment(CENTER);
        setIconTextGap(10);

        this.setBackground(Color.ORANGE);

    }*/

}
