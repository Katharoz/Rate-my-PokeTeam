package Pruebas;

import javax.swing.*;
import java.awt.*;

class Frame extends JFrame{

    Frame(String nombreVentana, ImageIcon icono){

        this.setTitle(nombreVentana);                                                                                   //}Poner nombre e icono a la ventana.
        this.setIconImage(icono.getImage());                                                                            //}

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setBounds(400, 50, 700, 500);
        this.setMinimumSize(new Dimension(700, 700));

        Panel panel = new Panel();
        add(panel);

        setVisible(true);
    }

}
