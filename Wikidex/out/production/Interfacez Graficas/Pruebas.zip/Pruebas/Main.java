package Pruebas;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        List<Pokemon> listaPokemon = new ArrayList<>();

        String[] nombresPokemon = {"Venasaur","Charizard","Blastoise","Beedrill","Pikachu","Alakazam","Machamp","Gengar","Onix","Jynx","Snorlax","Dragonite","","Crear Equipo"};
        int[] nroPokemon = {3,6,9,15,25,65,68,94,95,124,143,149,82,0};

        for (int i=0;   i<14;    i++){
            ImageIcon asdf = new ImageIcon("iconos\\pokemon\\"+i+".png");
            listaPokemon.add(new Pokemon(nombresPokemon[i], asdf, nroPokemon[i]));
        }

        new Output_Input(listaPokemon);

        ImageIcon icono = new ImageIcon("iconos\\18316-200.png");                                               //Recibir el icono de la ventana.
        new Frame("Wikidex", icono);

    }

}
