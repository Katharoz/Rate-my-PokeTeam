package Pruebas;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

class Panel extends JPanel{

    Panel(){

        JLabel background = crearBackground();

        JPanel buttonPanel = crearBotones();

        this.add(background);
        background.setLayout(new FlowLayout());
        background.add( buttonPanel );

    }

    private static JLabel crearBackground(){

        ImageIcon pika = new ImageIcon("iconos\\pokemon-backgrounds-8.jpg");
        Image pikachu = pika.getImage().getScaledInstance(700, 656, Image.SCALE_SMOOTH);

        JLabel background = new JLabel(new ImageIcon(pikachu));
        background.setBounds(0,0, 500, 700);

        return background;

    }

    private static JPanel crearBotones(){

        JPanel buttonPanel = new JPanel( new GridLayout(7, 2, 6, 5) );
        buttonPanel.setBorder( new EmptyBorder(0, 0, 0, 0) );

        buttonPanel.setOpaque( false );

        List<Pokemon> listaPokemon = new ArrayList<>(Output_Input.Input());


        for (int i=0;   i<14;    i++) {

            Boton boton = new Boton(listaPokemon.get(i));
            boton.setPreferredSize( new Dimension(300, 75) );

            if (i==12){
                boton.setVisible(false);
            }

            buttonPanel.add(boton);


        }

        return buttonPanel;

    }

}
