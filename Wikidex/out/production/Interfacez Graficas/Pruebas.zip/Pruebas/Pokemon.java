package Pruebas;

import javax.swing.*;
import java.io.Serializable;

public class Pokemon implements Serializable {

    private String name;
    private ImageIcon pokemon;
    private int nroPokedex;

    //Constructor-------------------------------------------------------------------------------------------------------
    public Pokemon(String pokemonName, ImageIcon icono, int nro){
        this.name = pokemonName;
        this.pokemon = icono;
        this.nroPokedex = nro;
    }

    //Getters-----------------------------------------------------------------------------------------------------------
    String getName() {return this.name;}

    ImageIcon getPokemon() {return this.pokemon;}

    int getNroPokedex() {return  this.nroPokedex;}
}
