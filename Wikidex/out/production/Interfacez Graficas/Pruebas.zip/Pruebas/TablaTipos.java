package Pruebas;

import java.util.Scanner;

public class TablaTipos {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        String[][] tabla = new String[18][18];
        String[] tipos = {"acero","agua","bicho","dragon","electrico","fantasma","fuego","hielo","lucha","normal","planta","psiquico","roca","siniestro","tierra","veneno","volador"};

        for (int i=0;   i<18;   i++){
            for (int j=0;   j<18;   j++){

                if (i==0 && j==0)   continue;
                else if (i==0)   tabla[i][j] = tipos[j-1];
                else if (j==0)   tabla[i][j] = tipos[i-1];
                else tabla[i][j] = Integer.toString(i+j);

            }
        }

        for (String[] i: tabla) {
            for (String j: i) {
                System.out.print("[" +j+ "] ");
            }
            System.out.println();
        }

    }

}
